// Object 1: Transaction Feed Panel
function ModChip({ code }) {
  const m = MODALITIES.find(x => x.code === code) || MODALITIES[0];
  return (
    <span className={`mod mod-${code}`}>
      <span className="mod-dot"/>{m.label.toUpperCase().replace(' SCAN','')}
    </span>
  );
}

function TransactionFeed({ transactions, filters, setFilters, liveSync, showArabic }) {
  const [page, setPage] = useState(1);
  const pageSize = 8;

  const filtered = useMemo(() => {
    return transactions.filter(t => {
      if (filters.mod !== 'all' && t.mod !== filters.mod) return false;
      if (filters.q && !(`${t.id} ${t.code} ${t.en}`.toLowerCase().includes(filters.q.toLowerCase()))) return false;
      if (filters.range === 'today' && !sameDay(t.date, new Date(2026, 3, 22))) return false;
      if (filters.range === '7d') {
        const cutoff = new Date(2026, 3, 15);
        if (t.date < cutoff) return false;
      }
      return true;
    });
  }, [transactions, filters]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  useEffect(() => { if (page > totalPages) setPage(1); }, [totalPages, page]);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const modChips = ['all', ...MODALITIES.map(m => m.code)];

  return (
    <div className="card">
      <div className="card-head">
        <h2>
          <I.Activity size={15}/> Transaction Feed
          {liveSync && (
            <span className="live-pill">
              <span className="conn-dot" style={{width: 5, height: 5}}/>
              LIVE
            </span>
          )}
        </h2>
        <span className="sub">· Pushed from PACS-Gateway in real time</span>
        <div className="spacer"/>
        <button className="btn ghost sm" title="Refresh"><I.Clock size={13}/> Last 24h</button>
        <button className="btn sm"><I.Filter size={13}/> Filters</button>
        <button className="btn sm"><I.Download size={13}/></button>
      </div>

      <div className="controls">
        <div className="input" style={{minWidth: 240}}>
          <I.Search size={13} style={{color: 'var(--muted-2)'}}/>
          <input placeholder="Search by ID, exam code, description…"
                 value={filters.q}
                 onChange={e => setFilters(f => ({...f, q: e.target.value}))}/>
        </div>

        <div className="chip-row" style={{marginLeft: 4}}>
          {modChips.map(c => (
            <button key={c} className="chip-filter" aria-pressed={filters.mod === c}
                    onClick={() => setFilters(f => ({...f, mod: c}))}>
              {c !== 'all' && <span className="dot" style={{background: modColor(c)}}/>}
              {c === 'all' ? 'All modalities' : MODALITIES.find(m => m.code === c)?.label}
            </button>
          ))}
        </div>

        <div className="spacer" style={{flex: 1}}/>

        <select className="select" value={filters.range} onChange={e => setFilters(f => ({...f, range: e.target.value}))}>
          <option value="today">Today</option>
          <option value="7d">Last 7 days</option>
          <option value="all">All time</option>
        </select>
      </div>

      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th style={{width: 104}}>ID</th>
              <th style={{width: 126}}>Exam Code</th>
              <th>Description</th>
              <th style={{width: 100}}>Modality</th>
              <th className="num" style={{width: 110}}>Price (ex. tax)</th>
              <th style={{width: 130}}>Date</th>
              <th style={{width: 36}}></th>
            </tr>
          </thead>
          <tbody>
            {paged.map(t => (
              <tr key={t.id} className={t.isNew ? 'is-new' : ''}>
                <td>
                  <span className="id-badge"><span className="hash">#</span>{t.id.replace('TX-','')}</span>
                </td>
                <td><span className="exam-code">{t.code}</span></td>
                <td className="desc-cell">
                  <div className="desc-en">{t.en}</div>
                  {showArabic && <div className="desc-ar">{t.ar}</div>}
                </td>
                <td><ModChip code={t.mod}/></td>
                <td className="num"><span className="mono">﷼ {t.price.toLocaleString()}</span></td>
                <td className="muted mono" style={{fontSize: 12}}>{fmtDate(t.date)}</td>
                <td>
                  <button className="icon-btn" style={{width: 28, height: 28}} title="More"><I.MoreH size={14}/></button>
                </td>
              </tr>
            ))}
            {paged.length === 0 && (
              <tr><td colSpan="7" style={{textAlign: 'center', padding: '40px 0', color: 'var(--muted)'}}>
                No transactions match these filters.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        Showing <strong style={{color: 'var(--ink)', margin: '0 4px'}}>{(page-1)*pageSize + 1}-{Math.min(page*pageSize, filtered.length)}</strong> of {filtered.length}
        <div className="spacer"/>
        <button className="pg-btn" onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1}><I.ChevronLeft size={13}/></button>
        {Array.from({length: Math.min(totalPages, 4)}).map((_, i) => {
          const n = i + 1;
          return <button key={n} className="pg-num" aria-current={page === n} onClick={() => setPage(n)}>{n}</button>;
        })}
        {totalPages > 4 && <span style={{color: 'var(--muted-2)'}}>…</span>}
        <button className="pg-btn" onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page === totalPages}><I.ChevronRight size={13}/></button>
      </div>
    </div>
  );
}

function modColor(c) {
  return { CT: '#3B82F6', MRI: '#8B5CF6', XR: '#F59E0B', US: '#0D9488', PET: '#F43F5E', NM: '#10B981', MG: '#EC4899' }[c] || '#94A3B8';
}

Object.assign(window, { TransactionFeed, ModChip, modColor });
