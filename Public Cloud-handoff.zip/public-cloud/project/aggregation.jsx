// Object 3: Monthly Exam Aggregation → Service Orders
function Aggregation({ transactions, onToast }) {
  const currentMonth = new Date(2026, 3, 22);
  const monthly = useMemo(() => transactions.filter(t => sameMonth(t.date, currentMonth)), [transactions]);

  const groups = useMemo(() => {
    const map = new Map();
    for (const t of monthly) {
      if (!map.has(t.code)) map.set(t.code, { code: t.code, en: t.en, ar: t.ar, mod: t.mod, price: t.price, items: [] });
      map.get(t.code).items.push(t);
    }
    return [...map.values()].sort((a, b) => b.items.length - a.items.length);
  }, [monthly]);

  const [openId, setOpenId] = useState(groups[0]?.code);
  const [orders, setOrders] = useState({});
  const [generating, setGenerating] = useState(null);

  const createOrder = (code) => {
    setGenerating(code);
    setTimeout(() => {
      const orderId = `SO-2026-${String(Math.floor(1000 + Math.random() * 8999))}`;
      setOrders(o => ({ ...o, [code]: orderId }));
      setGenerating(null);
      onToast(`Service order ${orderId} created`);
    }, 650);
  };

  const copy = (txt) => {
    navigator.clipboard?.writeText(txt);
    onToast(`Copied ${txt}`);
  };

  const totalTx = monthly.length;
  const createdCount = Object.keys(orders).length;

  return (
    <div className="card">
      <div className="agg-head">
        <div>
          <h2>
            <I.Clipboard size={15}/> Monthly Aggregation
            <span style={{fontSize: 11, fontWeight: 500, color: 'var(--muted)', padding: '2px 8px', borderRadius: 999, background: 'var(--surface-2)', border: '1px solid var(--border)'}}>April 2026</span>
          </h2>
          <div className="sub">Cases grouped by exam code · ready for service order creation</div>
        </div>
        <div className="spacer" style={{flex: 1}}/>
        <div className="agg-total"><strong>{groups.length}</strong> exam codes · <strong>{totalTx}</strong> cases · <strong>{createdCount}</strong> orders drafted</div>
        <button className="btn sm"><I.Calendar size={13}/> Change month</button>
      </div>

      <div className="agg-list">
        {groups.map(g => {
          const open = openId === g.code;
          const order = orders[g.code];
          return (
            <div key={g.code} className="agg-group" data-open={open}>
              <button className="agg-group-head" onClick={() => setOpenId(open ? null : g.code)}>
                <I.Chevron size={14} className="chev"/>
                <ModChip code={g.mod}/>
                <div className="code-wrap">
                  <div className="code-main">
                    <span className="exam-code">{g.code}</span>
                    <span style={{fontSize: 12.5, color: 'var(--ink-2)', fontWeight: 500}}>{g.en}</span>
                  </div>
                  <div className="code-desc ar" style={{textAlign: 'left'}}>{g.ar}</div>
                </div>
                <span className="count-pill">
                  <span>{g.items.length}</span>
                  <span className="lbl">cases</span>
                </span>
                <span className="count-pill">
                  <span className="mono">﷼ {(g.items.reduce((a,x) => a+x.price, 0)).toLocaleString()}</span>
                </span>
                {order ? (
                  <span className="created" title="Service order created">
                    <I.Check size={12}/> Order drafted
                  </span>
                ) : (
                  <span style={{fontSize: 11, color: 'var(--muted)', padding: '3px 8px', borderRadius: 999, background: 'var(--surface-2)', border: '1px solid var(--border)'}}>
                    Pending
                  </span>
                )}
              </button>

              {open && (
                <div className="agg-group-body">
                  <div className="agg-txn-list">
                    {g.items.map(t => (
                      <div key={t.id} className="agg-txn">
                        <span className="t-date">{fmtShortDate(t.date)}</span>
                        <span className="t-id">{t.id}</span>
                        <span className="t-price mono">﷼ {t.price.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  <div className="order-bar">
                    <div style={{fontSize: 12, color: 'var(--muted)', fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6}}>
                      <I.File size={13}/> Service Order ID
                    </div>
                    <div className="so-input">
                      {order ? (
                        <>
                          <input readOnly value={order}/>
                          <button className="copy-btn" onClick={() => copy(order)} title="Copy"><I.Copy size={13}/></button>
                        </>
                      ) : (
                        <span className="placeholder">— will populate after creation —</span>
                      )}
                    </div>
                    {order ? (
                      <button className="btn sm"><I.Check size={13}/> View order</button>
                    ) : (
                      <button className="btn primary sm" disabled={generating === g.code} onClick={() => createOrder(g.code)}>
                        {generating === g.code ? (
                          <><span className="conn-dot" style={{width: 5, height: 5, background: 'white'}}/> Creating…</>
                        ) : (
                          <><I.Plus size={13}/> Create Service Order</>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { Aggregation });
