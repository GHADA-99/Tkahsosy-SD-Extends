// Object 2: Modality Group Summary Panel
function GroupCard({ group, onToggle, onUpdate }) {
  const pct = Math.min(100, Math.round((group.qtyUpdated / group.qtyOrig) * 100));
  const finished = group.finished || pct >= 100;
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(group.qtyUpdated);

  useEffect(() => { setDraft(group.qtyUpdated); }, [group.qtyUpdated]);

  const commit = () => {
    const n = Math.max(0, Math.min(group.qtyOrig, parseInt(draft || 0, 10) || 0));
    onUpdate({ ...group, qtyUpdated: n, finished: n >= group.qtyOrig ? true : group.finished });
    setEditing(false);
  };

  return (
    <div className="group-card">
      <div className="head">
        <div className="icon-wrap" style={{background: modTintBg(group.modality), color: modColor(group.modality)}}>
          <ModIcon code={group.modality}/>
        </div>
        <div>
          <div className="name">{group.name}</div>
          <div className="meta">
            <ModChip code={group.modality}/>
            <span style={{marginLeft: 8}}>ID <span className="mono" style={{color: 'var(--ink-2)'}}>{group.id.toUpperCase()}</span></span>
          </div>
        </div>
        <div className="discount">{group.discount}% off</div>
      </div>

      <div className="qty-row">
        <div className="qty-tile">
          <div className="lbl">Original qty</div>
          <div className="val">{group.qtyOrig}</div>
        </div>
        <div className={"qty-tile" + (editing ? ' editable' : '')} onClick={() => setEditing(true)}>
          <div className="lbl" style={{display: 'flex', alignItems: 'center', gap: 4}}>
            Updated qty <I.Edit size={10} style={{opacity: .6}}/>
          </div>
          {editing ? (
            <input autoFocus type="number" min={0} max={group.qtyOrig} value={draft}
                   onChange={e => setDraft(e.target.value)}
                   onBlur={commit}
                   onKeyDown={e => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') { setDraft(group.qtyUpdated); setEditing(false); } }}/>
          ) : (
            <div className="val">
              {group.qtyUpdated}
              <span className="delta">+{group.qtyUpdated - Math.floor(group.qtyOrig * 0.3)}</span>
            </div>
          )}
        </div>
      </div>

      <div style={{position: 'relative', marginBottom: 16, marginTop: 16}}>
        <span className="pct" style={{position: 'absolute', right: 0, top: -16, fontSize: 11, color: 'var(--muted)', fontVariantNumeric: 'tabular-nums'}}>{pct}%</span>
        <div className={"progress " + (finished ? 'finished' : 'in-progress')}>
          <div style={{width: pct + '%'}}/>
        </div>
      </div>

      <div className="group-foot">
        <span className={"status-chip " + (finished ? 'finished' : 'in-progress')}>
          <span className="dot"/>
          {finished ? 'Finished' : 'In Progress'}
        </span>
        <span style={{fontSize: 11, color: 'var(--muted)', marginLeft: 'auto', marginRight: 4}}>Mark finished</span>
        <button className="switch" data-on={finished} onClick={() => onToggle(group)} aria-label="Toggle finished"/>
      </div>
    </div>
  );
}

function modTintBg(code) {
  return {
    CT: '#EFF6FF', MRI: '#F5F3FF', XR: '#FFFBEB', US: '#F0FDFA', PET: '#FFF1F2', NM: '#ECFDF5', MG: '#FDF2F8'
  }[code] || 'var(--surface-2)';
}
function ModIcon({ code, size = 18 }) {
  const common = { size, stroke: 1.75 };
  switch (code) {
    case 'CT':  return <I.Scan {...common}/>;
    case 'MRI': return <I.Layers {...common}/>;
    case 'XR':  return <I.Activity {...common}/>;
    case 'US':  return <I.Wifi {...common}/>;
    case 'PET': return <I.Zap {...common}/>;
    case 'NM':  return <I.BarChart {...common}/>;
    case 'MG':  return <I.Clipboard {...common}/>;
    default:    return <I.Scan {...common}/>;
  }
}

function ModalityGroups({ groups, setGroups }) {
  const toggle = (g) => setGroups(gs => gs.map(x => x.id === g.id ? { ...x, finished: !x.finished } : x));
  const update = (g) => setGroups(gs => gs.map(x => x.id === g.id ? g : x));
  const finishedCount = groups.filter(g => g.finished).length;

  return (
    <div className="card">
      <div className="card-head">
        <h2><I.Layers size={15}/> Modality Groups</h2>
        <span className="sub">· {finishedCount} of {groups.length} complete</span>
        <div className="spacer"/>
        <button className="btn ghost sm"><I.Sliders size={13}/> Bulk edit</button>
        <button className="btn primary sm"><I.Plus size={13}/> New group</button>
      </div>
      <div className="groups-grid">
        {groups.map(g => (
          <GroupCard key={g.id} group={g} onToggle={toggle} onUpdate={update}/>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ModalityGroups, GroupCard, ModIcon, modTintBg });
