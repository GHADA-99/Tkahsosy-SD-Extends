// Top-level app wiring
function App() {
  const [tweaks, setTweaks] = useState(window.__TWEAKS__);
  const [tweaksVisible, setTweaksVisible] = useState(false);
  const [transactions, setTransactions] = useState(() => buildTransactions(38));
  const [groups, setGroups] = useState(MODALITY_GROUPS);
  const [nav, setNav] = useState('dashboard');
  const [tab, setTab] = useState('all');
  const [filters, setFilters] = useState({ q: '', mod: 'all', range: 'all' });
  const [newCount, setNewCount] = useState(0);
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2200);
  }, []);

  // Tweaks-mode wiring
  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweaksVisible(true);
      else if (e.data?.type === '__deactivate_edit_mode') setTweaksVisible(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  // Apply dark/accent to root
  useEffect(() => {
    document.documentElement.dataset.theme = tweaks.dark ? 'dark' : 'light';
    document.documentElement.dataset.accent = tweaks.accent;
  }, [tweaks.dark, tweaks.accent]);

  // Simulated live sync — pushes a new transaction every ~7s
  useEffect(() => {
    if (!tweaks.liveSync) return;
    let idx = 0;
    const tick = () => {
      const nt = newTransactionAt(new Date(2026, 3, 22, 14, 12 + idx), idx);
      idx++;
      setTransactions(prev => [nt, ...prev.map(p => ({...p, isNew: false}))]);
      setNewCount(c => c + 1);
      // Clear isNew flag so animation only fires once
      setTimeout(() => {
        setTransactions(prev => prev.map(p => p.id === nt.id ? {...p, isNew: false} : p));
      }, 2500);
    };
    const t = setInterval(tick, 7000);
    return () => clearInterval(t);
  }, [tweaks.liveSync]);

  const counts = {
    tx: transactions.length,
    groups: groups.length,
    orders: 12,
  };

  const mainClass = "main" + (tweaks.density === 'compact' ? ' compact' : '');

  return (
    <div className="app">
      <TopBar
        notifCount={newCount}
        onToggleTheme={() => {
          const d = !tweaks.dark;
          setTweaks(t => ({...t, dark: d}));
          window.parent.postMessage({ type: '__edit_mode_set_keys', edits: {dark: d} }, '*');
        }}
        dark={tweaks.dark}/>
      <Sidebar current={nav} onNav={(id) => { setNav(id); setNewCount(0); }} counts={counts}/>

      <div className={mainClass}>
        <PageHeader
          title="Radiology Operations"
          subtitle="Live from PACS-Gateway · Central Imaging Dept · Apr 22, 2026"
          tab={tab} onTab={setTab}
          notifCount={newCount}
          liveCount={tab === 'feed' ? 0 : newCount}/>

        <KpiStrip tx={transactions} groups={groups}/>

        {(tab === 'all' || tab === 'feed') && (
          <div style={{marginBottom: tab === 'all' ? 16 : 0}}>
            <TransactionFeed
              transactions={transactions}
              filters={filters} setFilters={setFilters}
              liveSync={tweaks.liveSync}
              showArabic={tweaks.showArabic}/>
          </div>
        )}

        {(tab === 'all' || tab === 'groups' || tab === 'monthly') && (
          <div className={tab === 'all' ? 'panels' : ''} style={tab === 'all' ? {} : {}}>
            {(tab === 'all' || tab === 'monthly') && (
              <Aggregation transactions={transactions} onToast={showToast}/>
            )}
            {(tab === 'all' || tab === 'groups') && (
              <div style={tab === 'all' ? {} : {marginTop: 0}}>
                <ModalityGroups groups={groups} setGroups={setGroups}/>
              </div>
            )}
          </div>
        )}
      </div>

      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} visible={tweaksVisible}/>

      {toast && (
        <div className="toast"><I.Check size={13}/> {toast}</div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
